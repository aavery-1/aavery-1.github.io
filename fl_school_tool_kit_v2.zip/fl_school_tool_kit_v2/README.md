# Florida School Facilities Explorer: Build Kit (v2)

A self-contained package for having Claude (or any capable coding agent) build a professional-grade, layered map tool for exploring school-facilities data across **Miami-Dade, Broward, and Orange** counties. It is an internal analyst tool: a map you explore by toggling data layers and clicking schools. **No automated scoring, no ranking. The analyst's judgment stays in charge.**

## What changed in v2

Every original file was reviewed and revised. Two files were added. The full changelog:

- **00_BUILD_PROMPT.md** rewrites the prompt to require an understanding check before any code, includes the new files, adds tests and error handling to the acceptance checklist, and bans em dashes.
- **01_PRODUCT_SPEC.md** adds compare mode, CSV export, the corrected grade domain (`A, B, C, D, F, I, NR, NG`), color-plus-letter pin encoding, and explicit missing-data behavior.
- **02_DESIGN_SYSTEM.md** (new) defines the visual system: minimal floating panels over a full-bleed map, typography, color palette, component patterns, motion, accessibility, and attribution.
- **03_DATA_CATALOG.md** (was 02) corrects the grade era-break story (four breaks, not one), the OpenRouteService quota reality (40 isochrones/day free), the NCES EDGE lag, the Opportunity Zones 2018-vs-2027 status, Google Maps Platform 2025 pricing changes, and the parcel-scale reality (~800k in Miami-Dade alone).
- **04_SAMPLE_SCHEMAS.md** (new) specifies the exact fields and shapes of every committed sample file, matching the real published sources so the sample-to-real swap is a one-file edit per adapter.
- **05_ACCURACY_STANDARDS.md** (was 03) adds the color-plus-letter pin encoding, scale-bar semantics, the required automated test suite in `src/geo/__tests__/`, and the error-handling requirements.
- **06_ARCHITECTURE.md** (was 04) adds the Zustand state model, URL persistence, error boundaries, testing setup, region-generalization notes, deploy targets, and Node version pinning.
- **07_LAYERS.config.json** (was 05) splits `layers[]` (renders on map) from `datasets[]` (feeds inspector), adds per-layer `style` blocks with color ramps and pin styles, adds `zOrder`, `minZoom`, `maxZoom`, and defines the `renderTypes` registry.

## How to use this folder

1. Download and unzip this folder somewhere you can point Claude at it (Claude Code, or attach the files to a new chat).
2. Paste the contents of **`00_BUILD_PROMPT.md`** as your message. It tells Claude to read the other files and build the app.
3. Provide your own Google Maps JavaScript API key when prompted (see `.env.example` that the build produces).
4. Run the app per the README Claude generates.

## What "one-shot" realistically delivers

A runnable, professional front end (React 18 + TypeScript + Vite + Google Maps + deck.gl + turf.js + Zustand + Vitest): the layered-map UX, the school inspector, compare mode, CSV export, geodesic measurement, an accurate scale bar, sample data for the MVP layers, and a documented data adapter for every layer in the catalog with `TODO` seams where the real source connects. Plus a small automated test suite that enforces the correctness claims.

**Not in the one-shot:** live ingestion of all 13 datasets, a hosted database, or production deployment. Those are a documented second pass. The architecture is built to receive them.

## Files

| File | Purpose |
|---|---|
| `00_BUILD_PROMPT.md` | The master prompt to paste to Claude. Start here. |
| `01_PRODUCT_SPEC.md` | What the tool is: users, UX, inspector, compare, export, phases. |
| `02_DESIGN_SYSTEM.md` | Visual system, component patterns, color, typography, accessibility. |
| `03_DATA_CATALOG.md` | All 13 layers: source, access, resolution, join key, cost, gotchas. |
| `04_SAMPLE_SCHEMAS.md` | Exact fields and shapes for every committed sample file. |
| `05_ACCURACY_STANDARDS.md` | Correctness, performance, test, and presentation rules. |
| `06_ARCHITECTURE.md` | Stack, folder structure, state model, error handling, tests. |
| `07_LAYERS.config.json` | Machine-readable layer + dataset definitions the app is built from. |
| `FL_school_facilities_data_catalog.xlsx` | The catalog as a spreadsheet, for humans. |

## Assumptions baked in (change in the prompt if wrong)

- Stack: React 18 + TypeScript (Vite), Google Maps JS API base, deck.gl overlays, turf.js for geometry, Zustand for state, Vitest for tests.
- Node 20 LTS, npm as package manager.
- Neutral professional design system with off-white surfaces and semantic grade colors; brand tokens (CSGF, KIPP, or other) drop into `src/theme.ts` later.
- Data reflects Claude's knowledge to roughly January 2026 with no live web access. Verify sources per the catalog's caveats before wiring real data.

## Anti-patterns this kit explicitly rejects

- Composite scoring or ranking of sites (the analyst decides, not the tool).
- Grade encoding by color alone (color + letter, always).
- Draw-a-trend-line across grading-formula changes (dividers only).
- Pixel-circle radius rings (geodesic buffers, always).
- Silent data drops on validation failure (fail loud, per layer).
- Marketing copy in the UI ("Discover", "Explore", "Powerful", etc.).
- Em dashes in code, UI, or docs.
